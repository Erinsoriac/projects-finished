package model;

import java.util.List;
import java.util.ArrayList;
import java.util.Collections;

public class Catalog {

	public Catalog()
	{
		
	}
	
	public void addIssue(Issue issue)
	{
		this.catalogContents.add(issue);
		Collections.sort(this.catalogContents);
	}
	
	public int numberOfIssues()
	{
		return this.catalogContents.size();
	}
	
	public Issue getIssue(int index)
	{
		if(index <= this.catalogContents.size())
			return this.catalogContents.get(index);
		else
			return null;
	}
	
	public Issue getLastIssue()
	{
		return this.catalogContents.get(this.catalogContents.size() - 1);
	}
	
	public Issue search(int volume, int number)
	{
		int foundIndex;
		Issue key = new Issue(volume, number);
		List<Issue> issues = new ArrayList<Issue>();
		issues = this.catalogContents;
		Collections.sort(issues);
		foundIndex = Collections.binarySearch(issues, key);
		if(foundIndex>-1)
			return issues.get(foundIndex);
		
		return null;
	}
	
	public Article search(String code)
	{
		int foundIndex;
		Article key = new Article(null, code);
		List<Article> articles = new ArrayList<Article>();
		
		for(int i=0; i< this.numberOfIssues(); i++)
		{
			articles = this.catalogContents.get(i).getArticles();		
			Collections.sort(articles);
			foundIndex = Collections.binarySearch(articles, key);
			if(foundIndex > -1)
				return articles.get(foundIndex);
		}
		return null;

	}
	
	public List<Issue> getContents()
	{
		return this.catalogContents;
	}
	
	public String toString()
	{
		return "Issues in this Catalog:\n" + this.catalogContents;
	}
	
	
	
	private List<Issue> catalogContents = new ArrayList<Issue>();
}

package model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Issue implements Comparable<Issue> 
{

	public Issue(int volume, int number)
	{
		issueVolume=volume;
		issueNumber=number;
		
	}
	
	public Issue()
	{
		
	}
	
	public int getVolume()
	{
		return this.issueVolume;
	}
	
	public void setVolume(int volume)
	{
		this.issueVolume = volume;
	}
	
	public int getNumber()
	{
		return this.issueNumber;
	}
	
	public void setNumber(int number)
	{
		this.issueNumber = number;
	}
	
	public int numberOfArticles()
	{
		return this.issueArticles.size();
	}
	
	public void addArticle(Article article)
	{
		this.issueArticles.add(article);
		article.setIssue(this);
		Collections.sort(this.issueArticles);
	}
	
	public Article getArticle(int index)
	{
		return this.issueArticles.get(index);
	}
	
	public Article getLastArticle()
	{
		return this.issueArticles.get(this.issueArticles.size());
	}
	
	public List<Article> getArticles()
	{
		return this.issueArticles;
	}
	
	public String toString()
	{
		return "Volume: " + this.getVolume() + ", Number: " + this.getNumber() + ".\n" /** + this.issueArticles + "\n\n" **/;
	}
	
	public boolean equals(Object obj)
	{
		return this == obj;
	}
	
	public int compareTo(Issue obj)
	{
		if (this.issueVolume>obj.issueVolume || (this.issueVolume == obj.issueVolume && this.issueNumber > obj.issueNumber))
			return 1;
		else if (this.issueVolume == obj.issueVolume && this.issueNumber == obj.issueNumber)
			return 0;
		else
			return -1;
	}
	
	private List<Article> issueArticles = new ArrayList<Article>();
	private int issueVolume;
	private int issueNumber;
	
}

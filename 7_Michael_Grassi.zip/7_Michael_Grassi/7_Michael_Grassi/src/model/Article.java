package model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Article implements Comparable<Article> 
{

	private String articleTitle;
	private String articleCode;
	public Map<String, String> articleAuthors = new HashMap<String, String>();
	private Issue theissue;
	
	public Article(String title, String code)
		{
		articleTitle = title;
		articleCode = code;
		}
	
	public String getCode()
		{
		return this.articleCode;
		}
	
	public String getTitle()
		{
		return this.articleTitle;
		}
	
	public int numberOfAuthors()
		{
		return articleAuthors.size();
		}
	
	public void addAuthor(String name, String pos)
		{
		if(!articleAuthors.containsKey(pos) && name != null && pos != null)
			{
			articleAuthors.put(pos, name);
			}
		}
	
	public String getAuthor(String pos)
		{
		return articleAuthors.get(pos);
		}
	
	public Map<String, String> getAuthors()
		{
		if (articleAuthors.size()>0)
			return articleAuthors;
		else	
			return null;
		}
	
	public String toString()
		{
		return  this.articleCode + ":  " + this.articleTitle ;
		}
	
	public boolean equals(Object obj)
		{
		if (this.articleCode.equals(obj))
			return true;
		else
			return false;
		}	

	public int compareTo(Article obj)
	{
		int result = this.articleCode.compareTo(obj.articleCode);
		return result;
	}

	public String allString()
	{
		return "Title: '" +this.articleTitle + "'\n\nCode: " + this.articleCode + "\n\nAuthors: " + this.articleAuthors;
	}
	
	public void setIssue(Issue issue)
	{
		this.theissue = issue;
	}
	
	public Issue getIssue()
	{
		return this.theissue;
	}
	
}

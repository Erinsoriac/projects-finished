import java.util.Scanner;

public class Queens{
	
	static final public boolean DEBUG = true; 
	
	public Queens(int r, int n, Queens q)
	{
		row = r;
		columns=n;
		neighbor = q;
	}
	
	public int getColumns(){ return columns;}
	public int getRows(){return row;}
	public Queens getNeighbor(){return neighbor;}
	Queens lastQueen = null;
	
	public String findFirstSolution(int n)
	{	
		for (int i = 1; i <= n; i++)
		{
			Queens queen = new Queens(1, i, lastQueen);
			if(queen.findSolution())
				lastQueen = queen;
			else
				{
				System.out.println("The" + n +"-Queens problem doesn't have a solution!\n" + "\t (Queen " + queen.getColumns()+")");
				}
		}
		return textQueenSolution(lastQueen, true, n);
	}
		
	public String findNext(int n)
	{
		int noretry=0;
		lastQueen.getRows();
		lastQueen.getNeighbor();
		if (row<n && noretry==0)
		{
			lastQueen.row++;
			noretry++;
		}
		else if (noretry==0)					// No clue if this actually works as I hope, since there were no values within the limit I put on N in which to test it.
		{
			neighbor.row++;
			noretry++;
		}
		Queens queen = new Queens(lastQueen.row, lastQueen.columns, lastQueen.neighbor);
		for (int i = 1; i <= n; i++)
		{
			if(queen.findSolution())
				lastQueen = queen;
			else
				{
				System.out.println("The" + n +"-Queens problem doesn't have a solution!\n" + "\t (Queen " + queen.getColumns()+")");
				}
			}	

		return textQueenSolution(lastQueen, true, n);
	}
	
	public boolean findSolution()
	{
		if (neighbor == null)
		{
			return true;
		}
		while (neighbor.canAttack(row, columns))
		{
			if(!next())
			{
				if (DEBUG)
					System.out.println("Queen " + columns +" failed to find a solution!");
				return false;
			}
		}
		return true;
	}
	
	
	public boolean next(){
		if (row < n){
			row = row + 1; 
			return findSolution(); 
		}
		
		//cannot go further, i.e. row == N
		if (neighbor== null || !neighbor.next())
		{
			if (DEBUG)
			{
				System.out.println("Queen " + columns +"' neighbor failed to find a solution!");
			}
		    
			return false;
		}
		else
		{
			row = 1;
			return(findSolution());
		}
	}
	
	public boolean canAttack(int row, int column)
	{
		
		if (row == this.row) return true; 
		int cd = this.columns - column; 
		if ((this.row + cd == row) ||(this.row - cd == row))
		{
			return true;
		}
		
		if (neighbor == null) return false; 
		else
			return neighbor.canAttack(row, column);
	}
	
	private String textQueenSolution(Queens q, boolean found, int n){
		if (found)
		{
			StringBuffer buf = new StringBuffer();
			if (q.getNeighbor() == null)
			{
				buf.append("[" + q.getRows());
			}
			else
			{
				buf.append(textQueenSolution(q.getNeighbor(), found, n));
				buf.append(", " + q.getRows());
			}
			if (q.columns == n)
				buf.append("]");
			return buf.toString();
		}
		else
		{
			return "";
		}
	}
	
	private int columns;
	private int row;
	private static int n;
	public Queens[] qs = null;
	public Queens neighbor;

	static public int GetNumber()
	{
	Scanner reader = new Scanner(System.in);
		while (n<1|| n>16)
		{
		System.out.println ( "Enter an integer between 1 and 16" );
		n = reader.nextInt();
		}
	reader.close();
	return n;
	}
	
	static public void main(String[] args)
	{

	int n = GetNumber();
	Queens problem = new Queens(1, n, null);
	//since the method findFirstSolution() returns a String, I can display it directly.
	System.out.println(problem.findFirstSolution(n));
	//since the method findNext() returns a String, I can display it directly.
	System.out.println(problem.findNext(n));
	}

}
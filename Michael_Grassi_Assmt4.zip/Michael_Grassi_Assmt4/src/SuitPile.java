
class SuitPile extends CardPile 
{

	SuitPile (int x, int y) { super(x, y); }

	public boolean canTake (Card aCard) 
		{
		if (empty())
			return true;   // aCard.rank() == 0;
		Card topCard = top();
		return (aCard.suit() == topCard.suit()) &&
			(aCard.rank() == 1 + topCard.rank());
		}
	
	public void select(int tx, int ty) 
	{
	Card topCard = top();
	topCard = pop();
	for (int i = 0; i < 7; i++)
		if (Game.tableau[i].canTake(topCard)) 
			{
			Game.tableau[i].addCard(topCard);
			return;
			}
	addCard(topCard);
	}
	// Place an if statement to place a suitpile card into the tableau.
}
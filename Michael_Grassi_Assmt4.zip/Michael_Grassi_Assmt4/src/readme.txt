I adjusted the DeckPile file in order to repopulate the deckpile, effectively using the existing shuffling method to repopulate the deckpile when an empty pile was clicked, and there are cards in the discard.


For sending cards from the tableau to empty suit piles, I simply adjusted a conditional in the suitPile to make it so that an empty suitpile always returned true on the "can take" check.


For sending cards from the suit piles to the tableau, I simply used a skimmed down version of the tableau's selection function.


For sending royalty cards of any level to empty tableau piles, I simply adjusted the canTake value for empty tableau piles appropriately.


Unfortunately, I couldn't think of any particularly fun things to add, so instead, I just added in a bit of a safeguard, to stop from accidentally sending a card from the discard pile to an empty suit pile.
I accomplished this by creating additional conditionals inside the discardPile's select function to prevent it from adding a non-Ace to an empty pile with a single exception.
This intentional exception is in a situation wherein a tableau pile has a card that would be able to be placed on the discard pile's card, were the discard pile card to be moved to the suitPile.
I figured this would be a reasonable exception to make, as it would allow one to potentially peel off a card from the tableau through this method if one so desired.
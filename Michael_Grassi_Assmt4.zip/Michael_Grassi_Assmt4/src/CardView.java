
abstract class CardView 
{
	public abstract void display (Card aCard, int x, int y);
	
	public static int Width = 50; 
	public static int Height = 70;

}

/*
    CSCV337 Web Programming - Provided File
    vigenere.js
    Notes:  You may add functions to this script to organize your code.  I've included JavaScript-based QUnit tests
    you can use to validate your implementation of the algorithm, which refer to the encrypt/decrypt functions.
    Include vigenere.js within your HTML file.
*/

"use strict";

function encrypt(plaintext, key)
{
    var ciphertext = "";
    // TODO: Put your encryption logic here.  Assign the resulting ciphertext to the ciphertext variable.


	if (key.length == 0)
		{
		throw 'You did not put in a key';
    alert("You did not put in a key");
		return;
		}

  if (plaintext.length == 0)
    {
    throw 'You did not enter a message.';
    alert("You did not enter a message");
    return;
    }

	var properKey = [];

	for (var i = 0; i < key.length; i++)
		{
		var k = key.charCodeAt(i);
		if (k >=65  && k <= 90 || k>=97 && k <= 122)
			{
			properKey.push((k-65)%32);
			}
    else if (k != 32)
      {
      throw 'Invalid characters in key';
      alert("Invalid characters in key");
      return;
      }
		}

	if (properKey.length == 0)
		{
		alert("There are no letters in the key.");
		return;
		}

	for (var i = 0, x = 0; i < plaintext.length; i++)
		{
		var character = plaintext.charCodeAt(i);
		if (character >= 65 && character <=90)
			{
			ciphertext += String.fromCharCode((character - 65 + properKey[x % properKey.length]) % 26 + 65);
			x++
			}
		else if (character >= 97 && character <= 122)
			{
			ciphertext += String.fromCharCode((character - 97 + properKey[x % properKey.length]) % 26 + 97);
			x++
			}
		else
			{
			ciphertext += plaintext.charAt(i);
			}
		}

    return ciphertext;
}

function decrypt(ciphertext, key)
{

    var plaintext = "";

    // TODO: Put your decryption logic here.  Assign the resulting plaintext to the plaintext variable.

	if (key.length == 0)
		{
		throw 'You did not put in a key';
    alert("You did not put in a key");
		return;
		}

  if (ciphertext.length == 0)
    {
    throw 'You did not enter a message';
    alert("You did not enter a message");
    return;
    }

	var properKey = [];

	for (var i = 0; i < key.length; i++)
		{
		var k = key.charCodeAt(i);
		if (k >=65  && k <= 90 || k>=97 && k <= 122)
			{
			properKey.push((k-65)%32);
			}
    else if (k != 32)
      {
      throw 'Invalid characters in key';
      alert("Invalid characters in key");
      return;
      }
		}

	if (properKey.length == 0)
		{
		alert("There are no letters in the key.");
		return;
		}

	for (var i = 0; i<properKey.length; i++)
		{
		properKey[i] = (26 - properKey[i]) % 26;
		}

	for (var i = 0, x = 0; i < ciphertext.length; i++)
		{
		var character = ciphertext.charCodeAt(i);
		if (character >= 65 && character <=90)
			{
			plaintext += String.fromCharCode((character - 65 + properKey[x % properKey.length]) % 26 + 65);
			x++
			}
		else if (character >= 97 && character <= 122)
			{
			plaintext += String.fromCharCode((character - 97 + properKey[x % properKey.length]) % 26 + 97);
			x++
			}
		else
			{
			plaintext += ciphertext.charAt(i);
			}
		}


    return plaintext;
}

function htmlEncrypt()
{
  var plaintext=document.getElementById("plaintext").value;
  var key=document.getElementById("encryptionKey").value;

	if (key.length == 0)
		{
		throw 'You did not put in a key';
    alert("You did not put in a key");
		return;
		}

  if (plaintext.length == 0)
    {
    throw 'You did not enter a message.';
    alert("You did not enter a message");
    return;
    }

  var encryptedMessage = document.getElementById("encryptedMessage");
  encryptedMessage.value = encrypt(plaintext, key);
}

function htmlDecrypt()
{
  var ciphertext=document.getElementById("ciphertext").value;
  var key=document.getElementById("decryptionKey").value;

  var decryptedMessage = document.getElementById("decryptedMessage");
  decryptedMessage.value = decrypt(ciphertext, key);

}
